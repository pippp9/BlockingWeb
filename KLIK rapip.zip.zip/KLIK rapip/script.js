const products = [
    { id: 1, name: "Headphone Mini", category: "Elektronik", price: 100000, old: 125000, emoji: "🎧", bg: "#e9e5ff", rating: "4.9", colors: ["#27233e", "#d7d2ff", "#b9c7d9"], description: "Nikmati musik favorit dengan suara jernih dan nyaman digunakan sepanjang hari. Desain minimalis yang mudah dibawa ke mana saja." },
    { id: 2, name: "Tas Ransel", category: "Fashion", price: 150000, old: 180000, emoji: "🎒", bg: "#dff0ff", rating: "4.8", colors: ["#27233e", "#a6c8e5", "#d8b9a0"], description: "Tas ransel praktis dengan ruang penyimpanan luas. Cocok untuk sekolah, kuliah, kerja, maupun menemani perjalanan." },
    { id: 3, name: "Sepatu", category: "Fashion", price: 200000, old: 250000, emoji: "👟", bg: "#ffead7", rating: "4.9", colors: ["#e6c6a8", "#27233e", "#e9e5ff"], description: "Sepatu kasual dengan bentuk modern dan sol nyaman. Padukan dengan gaya sehari-hari untuk tampilan yang lebih percaya diri." },
    { id: 4, name: "Botol Minum", category: "Aksesori", price: 50000, old: 65000, emoji: "🧴", bg: "#e7e2ff", rating: "4.7", colors: ["#7e67ed", "#a7d9d0", "#f2a8b6"], description: "Botol minum ringan yang mudah dibawa dan pas untuk menemani aktivitas harian. Pilihan praktis untuk tetap terhidrasi." },
    { id: 5, name: "T-shirt", category: "Fashion", price: 75000, old: 90000, emoji: "👕", bg: "#ffe4f0", rating: "4.8", colors: ["#e7a8c8", "#fff", "#27233e"], description: "Kaos kasual dengan bahan lembut dan potongan simpel. Nyaman dipakai sehari-hari dan mudah dipadukan dengan outfit favorit." },
    { id: 6, name: "Topi", category: "Aksesori", price: 60000, old: 80000, emoji: "🧢", bg: "#e9e9f2", rating: "4.6", colors: ["#27233e", "#d9c9b4", "#a4b8d7"], description: "Topi bergaya simpel untuk melengkapi penampilan. Desain ringan dan mudah dipadukan untuk berbagai kegiatan." },
    { id: 7, name: "Jam Tangan", category: "Aksesori", price: 175000, old: 210000, emoji: "⌚", bg: "#e3f4e9", rating: "4.8", colors: ["#27233e", "#d2b18d", "#e5e5e5"], description: "Jam tangan elegan dengan desain modern yang cocok untuk acara santai maupun formal." },
    { id: 8, name: "Lampu Meja", category: "Elektronik", price: 120000, old: 145000, emoji: "💡", bg: "#fff1ce", rating: "4.7", colors: ["#f4c95d", "#fff", "#27233e"], description: "Lampu meja minimalis untuk membantu aktivitas membaca dan bekerja dengan suasana yang nyaman." }
];
const categories = ["Semua", "Elektronik", "Fashion", "Aksesori", "Rumah"];
let state = { page: "home", category: "Semua", search: "", sort: "featured", detailId: 1, detailQty: 1, detailColor: 0, cart: JSON.parse(localStorage.getItem("klikCart") || "{}"), lastOrder: null };
const app = document.getElementById("app");
const money = n => "Rp " + Number(n).toLocaleString("id-ID");
const productById = id => products.find(p => p.id === Number(id));
const cartItems = () => Object.entries(state.cart).map(([id, qty]) => ({ product: productById(id), qty })).filter(x => x.product && x.qty > 0);
const cartQty = () => cartItems().reduce((s, x) => s + x.qty, 0);
const subtotal = () => cartItems().reduce((s, x) => s + x.product.price * x.qty, 0);
const shipping = () => subtotal() > 0 ? 15000 : 0;
const total = () => subtotal() + shipping();
const saveCart = () => { localStorage.setItem("klikCart", JSON.stringify(state.cart)); document.getElementById("cartCount").textContent = cartQty(); };
const art = (p, cls = "product-art") => `<div class="${cls}" style="background:${p.bg}"><span class="emoji">${p.emoji}</span></div>`;
const card = p => `<article class="product-card">${art(p)}<h3>${p.name}</h3><div class="price">${money(p.price)} ${p.old ? `<span class="old-price">${money(p.old)}</span>` : ""}</div><div class="card-bottom"><span class="rating">★ ${p.rating}</span><button class="btn small" data-detail="${p.id}">Lihat</button></div></article>`;
const header = (title, desc) => `<div class="page-title"><h1>${title}</h1><p>${desc}</p></div>`;
function home() { return `<section class="hero"><div><div class="eyebrow">Belanja mudah</div><h1>Temukan barang favoritmu di KLIK.</h1><p>Harga bersahabat untuk kebutuhan sehari-hari. Temukan pilihan yang cocok untukmu.</p><button class="btn" data-page="products">Mulai Belanja <span>→</span></button></div><div class="hero-art"><div class="hero-circle"></div><div class="hero-bag">🛍️</div></div></section><div class="section-head"><div><h2>Produk Pilihan</h2><p>Temukan produk favorit dengan harga terbaik</p></div><a href="#" class="text-link" data-page="products">Lihat semua →</a></div><div class="product-grid">${products.slice(0, 4).map(card).join("")}</div><div class="section-head"><div><h2>Pilihan lainnya</h2><p>Produk untuk melengkapi harimu</p></div></div><div class="product-grid">${products.slice(4, 8).map(card).join("")}</div>`; }
function productsPage() { let list = products.filter(p => (state.category === "Semua" || p.category === state.category) && (p.name.toLowerCase().includes(state.search.toLowerCase()))); if (state.sort === "low")
    list.sort((a, b) => a.price - b.price); if (state.sort === "high")
    list.sort((a, b) => b.price - a.price); if (state.sort === "name")
    list.sort((a, b) => a.name.localeCompare(b.name)); return `${header("Semua Produk", "Temukan barang terbaik untuk kebutuhanmu.")}<div class="catalog-layout"><aside class="sidebar"><h3>Kategori</h3><div class="category-list">${categories.map(c => `<button class="category-btn ${state.category === c ? "active" : ""}" data-category="${c}">${c}</button>`).join("")}</div></aside><section><div class="catalog-toolbar"><span>${list.length} produk ditemukan</span><select id="sortProducts" aria-label="Urutkan produk"><option value="featured" ${state.sort === "featured" ? "selected" : ""}>Rekomendasi</option><option value="low" ${state.sort === "low" ? "selected" : ""}>Harga terendah</option><option value="high" ${state.sort === "high" ? "selected" : ""}>Harga tertinggi</option><option value="name" ${state.sort === "name" ? "selected" : ""}>Nama A–Z</option></select></div><div class="catalog-grid">${list.length ? list.map(card).join("") : `<div class="panel" style="grid-column:1/-1;text-align:center;padding:40px">Produk tidak ditemukan.</div>`}</div></section></div>`; }
function detailPage() { let p = productById(state.detailId) || products[0]; return `<div class="detail-layout">${art(p, "detail-art")}<section class="detail-info"><div class="eyebrow">${p.category}</div><h1>${p.name}</h1><div class="rating">★ ${p.rating} <span style="color:#9995ad">· 24 ulasan</span></div><div class="price">${money(p.price)} ${p.old ? `<span class="old-price">${money(p.old)}</span>` : ""}</div><p>${p.description}</p><div class="detail-label">Warna</div><div class="swatches">${p.colors.map((c, i) => `<button aria-label="Warna ${i + 1}" class="swatch ${state.detailColor === i ? "active" : ""}" style="background:${c}" data-color="${i}"></button>`).join("")}</div><div class="detail-label">Jumlah</div><div class="qty"><button data-qty="-1">−</button><span>${state.detailQty}</span><button data-qty="1">+</button></div><div class="detail-actions"><button class="btn" data-add="${p.id}" data-qty-add="${state.detailQty}">＋ Tambah ke Keranjang</button><button class="btn light" data-page="cart">Lihat Keranjang</button></div></section></div><div class="section-head"><div><h2>Produk lainnya</h2><p>Mungkin kamu juga suka</p></div></div><div class="product-grid">${products.filter(x => x.id !== p.id).slice(0, 4).map(card).join("")}</div>`; }
function summaryBox(buttonText, buttonAction) { return `<aside class="panel summary"><h3>Ringkasan Belanja</h3><div class="summary-line"><span>Subtotal</span><strong>${money(subtotal())}</strong></div><div class="summary-line"><span>Ongkir</span><strong>${money(shipping())}</strong></div><div class="summary-line summary-total"><span>Total</span><strong>${money(total())}</strong></div><button class="btn" ${buttonAction}>${buttonText} →</button></aside>`; }
function cartPage() { let items = cartItems(); if (!items.length)
    return `${header("Keranjang Belanja", "Produk yang kamu pilih akan muncul di sini.")}<div class="panel empty"><div class="empty-icon">🛍️</div><h2>Keranjangmu masih kosong</h2><p>Yuk, temukan produk favoritmu dan tambahkan ke keranjang.</p><button class="btn" data-page="products">Mulai Belanja</button></div>`; return `${header("Keranjang Belanja", "Periksa kembali produk pilihanmu sebelum checkout.")}<div class="cart-layout"><section class="panel"><div class="table-head"><span>Produk</span><span>Harga</span><span>Jumlah</span><span>Total</span><span></span></div>${items.map(({ product: p, qty }) => `<div class="cart-row"><div class="cart-product"><div class="mini-art" style="background:${p.bg}">${p.emoji}</div><span>${p.name}</span></div><span class="row-price">${money(p.price)}</span><div class="qty"><button data-cart-qty="${p.id}" data-change="-1">−</button><span>${qty}</span><button data-cart-qty="${p.id}" data-change="1">+</button></div><span class="row-price">${money(p.price * qty)}</span><button class="remove" aria-label="Hapus ${p.name}" data-remove="${p.id}">×</button></div>`).join("")}</section>${summaryBox("Lanjut Checkout", 'data-page="checkout"')}</div>`; }
function checkoutPage() { if (!cartQty())
    return cartPage(); return `${header("Checkout", "Isi informasi pengiriman untuk menyelesaikan pesanan.")}<form id="checkoutForm" class="checkout-layout"><section class="panel"><h3 style="margin:0 0 20px">Informasi Pengiriman</h3><div class="form-grid"><div class="field"><label for="fullName">Nama lengkap</label><input id="fullName" name="fullName" placeholder="Nama penerima" required></div><div class="field"><label for="phone">Nomor HP</label><input id="phone" name="phone" type="tel" placeholder="08xxxxxxxxxx" required pattern="[0-9+ -]{9,16}"></div><div class="field full"><label for="address">Alamat lengkap</label><textarea id="address" name="address" placeholder="Nama jalan, nomor rumah, RT/RW" required></textarea></div><div class="field"><label for="city">Kota/Kabupaten</label><input id="city" name="city" placeholder="Kota tujuan" required></div><div class="field"><label for="postal">Kode pos</label><input id="postal" name="postal" placeholder="Kode pos" required pattern="[0-9]{5}"></div></div><h3 style="margin:22px 0 12px">Metode Pembayaran</h3><label class="payment-option"><input type="radio" name="payment" value="Transfer Bank" checked> <span><strong>Transfer Bank</strong><br><small style="color:#88849d">Pembayaran melalui rekening bank</small></span></label><label class="payment-option"><input type="radio" name="payment" value="COD"> <span><strong>Bayar di Tempat (COD)</strong><br><small style="color:#88849d">Bayar saat pesanan diterima</small></span></label><label class="payment-option"><input type="radio" name="payment" value="E-Wallet"> <span><strong>E-Wallet</strong><br><small style="color:#88849d">Pembayaran dompet digital</small></span></label></section><aside class="panel summary"><h3>Ringkasan Pesanan</h3>${cartItems().map(({ product: p, qty }) => `<div class="summary-line"><span>${p.emoji} ${p.name} × ${qty}</span><strong>${money(p.price * qty)}</strong></div>`).join("")}<div class="summary-line"><span>Subtotal</span><strong>${money(subtotal())}</strong></div><div class="summary-line"><span>Ongkir</span><strong>${money(shipping())}</strong></div><div class="summary-line summary-total"><span>Total</span><strong>${money(total())}</strong></div><button class="btn" type="submit">Buat Pesanan ✓</button></aside></form>`; }
function successPage() { let o = state.lastOrder; if (!o)
    return `${header("Pesanan", "Informasi pesanan terakhir.")}<div class="panel empty"><div class="empty-icon">📦</div><h2>Belum ada pesanan</h2><button class="btn" data-page="products">Mulai Belanja</button></div>`; return `<div class="success-card"><div class="success-mark">✓</div><h1>Pesanan Berhasil!</h1><p>Terima kasih, ${escapeHtml(o.name)}. Pesanan kamu sudah kami terima dan sedang diproses.</p><div class="order-code">${o.code}</div><p>Total pembayaran<br><strong style="color:var(--ink);font-size:20px">${money(o.total)}</strong></p><p>Metode pembayaran: ${escapeHtml(o.payment)}</p><button class="btn" data-page="home">Kembali ke Beranda</button> <button class="btn light" data-page="products">Belanja Lagi</button></div>`; }
function aboutPage() { return `${header("Tentang KLIK.", "Belanja mudah, pilihan tepat untuk kebutuhan sehari-hari.")}<section class="hero about-hero"><div><div class="eyebrow">Kenali kami lebih dekat</div><h1>Belanja jadi lebih simpel.</h1><p>KLIK. hadir untuk membantu kamu menemukan produk pilihan dengan pengalaman belanja yang nyaman, praktis, dan menyenangkan.</p><button class="btn" data-page="products">Jelajahi Produk →</button></div><div class="hero-art"><div class="hero-circle"></div><div class="hero-bag">💜</div></div></section><div class="values-grid"><article class="value-card"><div class="value-icon">🎯</div><h3>Tujuan Kami</h3><p>Membuat kebutuhan sehari-hari mudah ditemukan dalam satu tempat dengan proses belanja yang sederhana.</p></article><article class="value-card"><div class="value-icon">💎</div><h3>Nilai Kami</h3><p>Mengutamakan kenyamanan, pilihan produk yang relevan, dan informasi harga yang jelas.</p></article><article class="value-card"><div class="value-icon">🤝</div><h3>Komitmen Kami</h3><p>Memberikan pengalaman belanja yang ramah, praktis, dan bisa diandalkan untuk semua pelanggan.</p></article></div><section class="panel"><h2 style="font-size:19px;margin:0 0 18px">Kenapa belanja di KLIK.?</h2><div class="why-panel"><div><h3>✦ Pilihan Produk</h3><p>Beragam kebutuhan dalam satu tempat agar kamu lebih mudah menemukan yang dicari.</p></div><div><h3>✦ Harga Bersahabat</h3><p>Informasi harga yang jelas dan pilihan produk untuk berbagai kebutuhan.</p></div><div><h3>✦ Proses Praktis</h3><p>Alur belanja sederhana dari memilih produk sampai menyelesaikan pesanan.</p></div></div></section>`; }
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function render() { document.querySelectorAll("[data-page]").forEach(el => el.classList.toggle("active", el.dataset.page === state.page)); saveCart(); if (state.page === "home")
    app.innerHTML = home(); if (state.page === "products")
    app.innerHTML = productsPage(); if (state.page === "detail")
    app.innerHTML = detailPage(); if (state.page === "cart")
    app.innerHTML = cartPage(); if (state.page === "checkout")
    app.innerHTML = checkoutPage(); if (state.page === "success")
    app.innerHTML = successPage(); if (state.page === "about")
    app.innerHTML = aboutPage(); document.getElementById("globalSearch").value = state.search; window.scrollTo({ top: 0, behavior: "smooth" }); }
function go(page) { state.page = page; render(); }
function addToCart(id, qty = 1) { state.cart[id] = (state.cart[id] || 0) + Number(qty); saveCart(); toast("Produk ditambahkan ke keranjang"); }
function toast(message) { let t = document.getElementById("toast"); t.textContent = message; t.classList.add("show"); clearTimeout(window.toastTimer); window.toastTimer = setTimeout(() => t.classList.remove("show"), 2300); }
document.addEventListener("click", e => { let el = e.target.closest("[data-page],[data-detail],[data-add],[data-category],[data-qty],[data-color],[data-cart-qty],[data-remove]"); if (!el)
    return; if (el.dataset.page) {
    e.preventDefault();
    go(el.dataset.page);
    return;
} if (el.dataset.detail) {
    state.detailId = Number(el.dataset.detail);
    state.detailQty = 1;
    state.detailColor = 0;
    go("detail");
    return;
} if (el.dataset.add) {
    addToCart(el.dataset.add, el.dataset.qtyAdd || 1);
    return;
} if (el.dataset.category) {
    state.category = el.dataset.category;
    render();
    return;
} if (el.dataset.qty) {
    state.detailQty = Math.max(1, state.detailQty + Number(el.dataset.qty));
    render();
    return;
} if (el.dataset.color !== undefined) {
    state.detailColor = Number(el.dataset.color);
    render();
    return;
} if (el.dataset.cartQty) {
    let id = el.dataset.cartQty;
    state.cart[id] = Math.max(0, (state.cart[id] || 0) + Number(el.dataset.change));
    if (!state.cart[id])
        delete state.cart[id];
    render();
    return;
} if (el.dataset.remove) {
    delete state.cart[el.dataset.remove];
    render();
    toast("Produk dihapus dari keranjang");
} });
document.getElementById("globalSearch").addEventListener("input", e => { state.search = e.target.value; if (state.page !== "products")
    state.page = "products"; render(); let input = document.getElementById("globalSearch"); input.focus(); input.setSelectionRange(input.value.length, input.value.length); });
document.addEventListener("change", e => { if (e.target.id === "sortProducts") {
    state.sort = e.target.value;
    render();
} });
document.addEventListener("submit", e => { if (e.target.id !== "checkoutForm")
    return; e.preventDefault(); if (!cartQty())
    return; let data = new FormData(e.target); state.lastOrder = { name: data.get("fullName"), payment: data.get("payment"), total: total(), code: "KLIK" + Math.random().toString(10).slice(2, 10) }; state.cart = {}; saveCart(); go("success"); });
render();
